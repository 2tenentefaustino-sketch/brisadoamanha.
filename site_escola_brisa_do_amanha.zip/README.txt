SITE ESCOLA BRISA DO AMANHÃ

PASSO 1
Coloque sua logo dentro da pasta com o nome:

logo.png

PASSO 2
Abra o arquivo:

index.html

PASSO 3
Para colocar o site online:
Acesse https://netlify.com
Arraste a pasta ou o arquivo index.html

Pronto. Seu site estará no ar.
